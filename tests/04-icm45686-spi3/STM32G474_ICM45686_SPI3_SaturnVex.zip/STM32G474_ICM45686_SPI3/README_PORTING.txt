Project rebuilt from the user-provided STM32G474_LED_IO_Toggle(1).zip project metadata and STM32G4 HAL/CMSIS tree.
Kept its actual .project and .cproject build natures/settings, adding only driver include paths and C++ nature.
Copied ICM app source and driver from previous port; TDK driver source is from provided H753 and unchanged.
SPI3 PC10/11/12, CS PD2. INT1 PA15, INT2 PB5. USART2 PB3/4.
IMPORTANT: firmware not built with installed STM32CubeIDE here; inspect compiler errors if any.
WARNING: .ioc still inherited baseline, runtime initializes SPI3/EXTI in C. Do not regenerate code without aligning IOC.
