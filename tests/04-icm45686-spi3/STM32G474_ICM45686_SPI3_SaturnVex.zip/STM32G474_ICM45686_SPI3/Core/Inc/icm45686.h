/**
 ******************************************************************************
 * @file    icm45686.h
 * @brief   STM32 HAL C++ wrapper for the TDK / InvenSense ICM-45686
 *          six-axis IMU (accelerometer + gyroscope) over a 4-wire SPI bus.
 *
 * @author  SaturnVex Firmware Team
 * @date    2026-08-01
 * @version 1.0.0
 *
 * @copyright
 * Copyright (c) 2026 Tuyen Nguyen (SaturnVex). All rights reserved.
 * Website: www.saturnvex.com  ·  Contact: support@saturnvex.com
 *
 * @license
 * SPDX-License-Identifier: MIT
 * Released under the MIT License. See the root LICENSE file for the full
 * license text. Third-party components used by this file (TDK InvenSense
 * driver, STMicroelectronics HAL) retain their own license terms; refer
 * to THIRD_PARTY_LICENSES.md.
 *
 * @details
 * ### Overview
 * `Icm45686` provides a thin C++ facade over the platform-independent
 * InvenSense C driver (`Drivers/ICM45686_TDK/imu/`). The class:
 *   - Owns an `inv_imu_device_t` context and wires the three transport
 *     callbacks (SPI read, SPI write, blocking microsecond delay).
 *   - Presents a engineering-unit API
 *     (`getAccelX_mss()`, `getGyroX_dps()`, ...) so application code can
 *     switch IMU vendors with minimal change.
 *   - Applies a fixed body-frame alignment matrix so that a level board
 *     reads accel = (0, 0, -g) — FRD convention shared with the previous
 *     previous IMU implementation.
 *
 * ### Sensor configuration
 *   - Output data rate: 3200 Hz for both accel and gyro (Low-Noise mode).
 *   - Full-scale range: ±16 g accel, ±2000 dps gyro.
 *   - INT1 pin: push-pull, active-HIGH, PULSE mode, UI-DRDY source.
 *   - Transport: 4-wire SPI (`UI_SPI4` driver interface), Mode 0, SPI3 on STM32G474.
 *
 * ### Usage
 * @code
 *   Icm45686 imu(&hspi4, GPIOF, GPIO_PIN_13);   // CS on PF13
 *
 *   if (imu.begin() != 0) Error_Handler();      // reset + probe + config
 *
 *   for (int i = 0; i < 20; ++i) {              // polling sanity
 *       HAL_Delay(100);
 *       imu.readSensor();
 *   }
 *
 *   imu.estimateBias(800);                      // stationary gyro cal
 *   imu.enableDrdyInterrupt();                  // hand-off to EXTI
 *
 *   // In HAL_GPIO_EXTI_Callback for PF15:
 *   //     imu.readSensor();
 * @endcode
 *
 * ### Thread / ISR safety
 * `readSensor()` is safe to call from an EXTI ISR: a single 15-byte SPI
 * burst that completes in ~24 µs at 6.25 MHz. The public getters are
 * plain member reads and require no locking as long as the reader
 * accepts the ISR-writer race window (single-word floats on Cortex-M7
 * are naturally atomic).
 *
 * @warning Do NOT call `enableDrdyInterrupt()` from inside `begin()`;
 *          the actively-pulsing INT1 line corrupts subsequent SPI
 *          bursts. Always finish any polling verification first.
 *
 * @see ICM-45686 datasheet DS-000577, InvenSense driver reference,
 *      SaturnVex application note SVX-AN-IMU-001.
 ******************************************************************************
 */

#ifndef INC_ICM45686_H_
#define INC_ICM45686_H_

/* ==== Includes ============================================================ */
#include "stm32g4xx_hal.h"
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

extern "C" {
#include "imu/inv_imu_driver.h"
#include "imu/inv_imu_driver_advanced.h"
}

/* ==== Class =============================================================== */

/**
 * @class   Icm45686
 * @brief   Object-oriented driver facade for the ICM-45686 IMU.
 */
class Icm45686 {
public:
    /* -------------------------------------------------------------------- */
    /*  Construction                                                         */
    /* -------------------------------------------------------------------- */

    /**
     * @brief  Construct a driver instance bound to a specific SPI bus and
     *         chip-select line.
     * @param  hspi     Handle of the SPI peripheral wired to the chip
     *                  (must be Master, 8-bit, Mode 0, SPI_NSS_SOFT).
     * @param  cs_port  GPIO port of the chip-select pin (e.g. GPIOF).
     * @param  cs_pin   GPIO pin bitmask of the chip-select pin
     *                  (e.g. GPIO_PIN_13).
     * @note   The constructor only initialises internal state; no SPI
     *         transaction is issued. Call begin() to talk to the chip.
     */
    Icm45686(SPI_HandleTypeDef *hspi, GPIO_TypeDef *cs_port, uint16_t cs_pin);

    /* -------------------------------------------------------------------- */
    /*  Initialisation                                                       */
    /* -------------------------------------------------------------------- */

    /**
     * @brief  Bring the ICM-45686 to a known, ready-to-read state.
     * @return 0   on success.
     * @return -1  WHO_AM_I never returned 0x E9 (wiring, power or bus fault).
     * @return other  Non-zero error code from the TDK driver.
     *
     * @details
     * Sequence:
     *   1. Enable DWT cycle counter (needed for sleep_us_cb).
     *   2. 20 ms POR settle.
     *   3. Force soft reset via REG_MISC2 = 0x02, wait 5 ms.
     *   4. Probe WHO_AM_I (0x72), retry up to five times (expect 0xE9).
     *   5. `inv_imu_adv_init()` — driver-level init.
     *   6. Configure accel and gyro: FSR, ODR, Low-Noise power mode.
     *   7. 100 ms settle so the first samples are valid.
     *
     * INT1 is intentionally left disabled — call enableDrdyInterrupt()
     * after any polling verification.
     */
    int begin();

    /**
     * @brief  Enable INT1 (data-ready) with push-pull, active-HIGH, pulse.
     * @return true on success, false on transport error.
     * @note   Wraps enableDrdyInt1(). Kept as a distinct public entry
     *         point so future variants (open-drain, latched, ...) can be
     *         added without breaking the call sites.
     */
    bool enableDrdyInterrupt() { return enableDrdyInt1(); }

    /**
     * @brief  Enable FIFO streaming with FIFO_THS interrupt on INT1.
     * @param  watermark  Number of samples in the FIFO required to raise
     *                    INT1. `watermark = 1` yields per-sample
     *                    interrupts (equivalent to DRDY latency).
     * @return true on success, false on transport error.
     *
     * @details
     * Alternative to enableDrdyInterrupt() when the application prefers
     * atomic sample snapshots inside the chip's FIFO — decouples SPI
     * reads from ODR-rate register updates.
     */
    bool enableFifoInterrupt(uint16_t watermark = 1);

    /* -------------------------------------------------------------------- */
    /*  Sample acquisition                                                   */
    /* -------------------------------------------------------------------- */

    /**
     * @brief  Read one gyro + accel + temperature sample in a single
     *         SPI burst (register path, `inv_imu_get_register_data`).
     * @note   Blocking, ~24 µs at 6.25 MHz SPI. Safe to call from an
     *         EXTI ISR. Results are stored in the member fields and
     *         retrievable via the get*() accessors.
     */
    void readSensor();

    /**
     * @brief  Pop one frame from the on-chip FIFO and unpack it into
     *         the member state.
     * @return true if a valid frame was available and decoded;
     *         false when the FIFO was empty or the frame header
     *         indicates a config/status packet.
     */
    bool readFromFifo();

    /* -------------------------------------------------------------------- */
    /*  Accessors (engineering units, bias-corrected, body frame)            */
    /* -------------------------------------------------------------------- */

    float getGyroX_dps()     const { return gyro_dps[0]; }
    float getGyroY_dps()     const { return gyro_dps[1]; }
    float getGyroZ_dps()     const { return gyro_dps[2]; }
    float getAccelX_mss()    const { return accel_mss[0]; }
    float getAccelY_mss()    const { return accel_mss[1]; }
    float getAccelZ_mss()    const { return accel_mss[2]; }
    float getTemperature_C() const { return temp_c; }

    /* -------------------------------------------------------------------- */
    /*  Gyro bias (dps)                                                      */
    /* -------------------------------------------------------------------- */

    /**
     * @brief  Manually load a gyro bias vector to be subtracted from
     *         every subsequent readSensor().
     */
    void  setBias(float bx_dps, float by_dps, float bz_dps);

    float getBiasX_dps() const { return bias_gyro_dps[0]; }
    float getBiasY_dps() const { return bias_gyro_dps[1]; }
    float getBiasZ_dps() const { return bias_gyro_dps[2]; }

    /**
     * @brief  Estimate the gyro bias by averaging N stationary samples.
     * @param  n_samples  Number of samples to average. 800 samples at
     *                    3200 Hz ODR is ~0.25 s and typically enough.
     * @warning The board must be perfectly stationary while this runs.
     */
    void estimateBias(unsigned n_samples);

    /* -------------------------------------------------------------------- */
    /*  Accel bias (m/s²)                                                    */
    /* -------------------------------------------------------------------- */

    /**
     * @brief  Manually load an accel bias vector to be subtracted from
     *         every subsequent readSensor(). Useful for six-position
     *         calibrations produced offline.
     */
    void  setAccelBias(float bx_mss, float by_mss, float bz_mss);

    float getAccelBiasX_mss() const { return bias_accel_mss[0]; }
    float getAccelBiasY_mss() const { return bias_accel_mss[1]; }
    float getAccelBiasZ_mss() const { return bias_accel_mss[2]; }

    /* -------------------------------------------------------------------- */
    /*  Compile-time facts                                                   */
    /* -------------------------------------------------------------------- */

    /** Effective gyro output data rate in Hz (must match begin() config). */
    static constexpr uint32_t GYRO_ODR_HZ  = 3200u;

    /** Effective accel output data rate in Hz. */
    static constexpr uint32_t ACCEL_ODR_HZ = 3200u;

    /* -------------------------------------------------------------------- */
    /*  Transport callbacks — invoked by the TDK C driver                    */
    /*  Public because the C driver takes plain function pointers; must     */
    /*  not be called by application code.                                  */
    /* -------------------------------------------------------------------- */
    static int  spi_read_cb (void *ctx, uint8_t reg, uint8_t *buf, uint32_t len);
    static int  spi_write_cb(void *ctx, uint8_t reg, const uint8_t *buf, uint32_t len);
    static void sleep_us_cb (uint32_t us);

    /**
     * @brief  Expose the underlying TDK driver context for advanced use
     *         (e.g. querying FIFO count, calling advanced APIs directly).
     * @note   Intended for debug or advanced integrations. Prefer the
     *         wrapped API for normal usage.
     */
    inv_imu_device_t *getDriverForDebug() { return &drv_; }

private:
    /* -------------------------------------------------------------------- */
    /*  Internal                                                             */
    /* -------------------------------------------------------------------- */

    bool enableDrdyInt1();

    /* Body-frame alignment (FRD coordinate convention).         *
     *   accel_body[i] = Σ_j t{i}[j] * accel_raw[j]                         */
    static const int8_t tX[3];
    static const int8_t tY[3];
    static const int8_t tZ[3];

    /* Hardware binding */
    SPI_HandleTypeDef *hspi_;
    GPIO_TypeDef      *cs_port_;
    uint16_t           cs_pin_;

    /* TDK driver context */
    inv_imu_device_t   drv_;

    /* Scale factors: raw / 32768 × FSR */
    float gyro_range_dps_;
    float accel_range_g_;

    /* Latest reading — bias-corrected, in body frame */
    float gyro_dps[3];
    float accel_mss[3];
    float temp_c;

    /* Bias vectors subtracted inside readSensor() and readFromFifo() */
    float bias_gyro_dps[3];
    float bias_accel_mss[3];
};

#endif /* INC_ICM45686_H_ */
