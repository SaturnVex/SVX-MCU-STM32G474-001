/**
 * @file app.cpp
 * @brief STM32G474 ICM-45686 SPI3 sensor verification application.
 *
 * Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
 * www.saturnvex.com | support@saturnvex.com
 * SPDX-License-Identifier: MIT
 *
 * SPI3: PC10 SCK, PC11 MISO, PC12 MOSI; PD2 chip select.
 * INT1: PA15 (DRDY); INT2: PB5 (diagnostic counter).
 * USART2: PB3 TX, PB4 RX; LED outputs: PB2 and PB10.
 * Sensor settings: accelerometer 3200 Hz / +/-16 g;
 *                  gyroscope 3200 Hz / +/-2000 dps.
 */

#include "icm45686.h"
#include <cstdio>

extern "C" {
/* SPI handle declared by main.c */
extern SPI_HandleTypeDef hspi3;
#include "main.h"
}

/* ------------------------------------------------------------------------- */
/* Pin mapping (matches CubeMX .ioc GPIO config)                             */
/* ------------------------------------------------------------------------- */
#define ICM_CS_PORT     GPIOD
#define ICM_CS_PIN      GPIO_PIN_2
#define ICM_INT1_PIN    GPIO_PIN_15
#define ICM_INT2_PIN    GPIO_PIN_5
#define LED_PORT        GPIOB
#define LED_PIN         GPIO_PIN_2

/* ------------------------------------------------------------------------- */
/* Global driver context (non-static for debugger Live Expressions).         */
/* ------------------------------------------------------------------------- */
Icm45686 g_imu(&hspi3, ICM_CS_PORT, ICM_CS_PIN);

/* ------------------------------------------------------------------------- */
/* ISR ↔ main flags and counters                                             */
/* ------------------------------------------------------------------------- */
volatile uint8_t  g_data_ready  = 0;
volatile uint32_t g_drdy_count  = 0;   /* PA15 INT1 DRDY */
volatile uint32_t g_int2_count  = 0;   /* PB5 INT2 (diagnostic) */

/* Live rate estimates updated every 1 s from main loop. */
volatile uint32_t g_drdy_rate_hz = 0;
volatile uint32_t g_int2_rate_hz = 0;

/* ------------------------------------------------------------------------- */
/* EXTI callback                                                             */
/*   PA15 (INT1 DRDY): read one sample in ISR context, set data-ready flag.  */
/*   PB5 (INT2)     : counter only.                                         */
/* ------------------------------------------------------------------------- */
extern "C" void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if (GPIO_Pin == ICM_INT1_PIN) {
        g_imu.readSensor();
        g_data_ready = 1;
        g_drdy_count++;
    } else if (GPIO_Pin == ICM_INT2_PIN) {
        g_int2_count++;
    }
}

/* ------------------------------------------------------------------------- */
/* app_main — invoked from main() after CubeMX-generated init                */
/* ------------------------------------------------------------------------- */
extern "C" void app_main(void)
{
    printf("=== STM32G474 ICM45686 SPI3 ===\r\n");
    printf("SYSCLK=%lu; SPI3 Mode0; INT1 PA15; INT2 PB5\r\n",(unsigned long)HAL_RCC_GetSysClockFreq());
    /* Deassert CS (idle HIGH) and let the chip settle after POR. */
    HAL_GPIO_WritePin(ICM_CS_PORT, ICM_CS_PIN, GPIO_PIN_SET);
    HAL_Delay(20);

    /* Initialize ICM45686: soft reset, WHO_AM_I probe, ODR/range/LN mode. */
    int init_rc = g_imu.begin();
    printf("ICM init rc=%d\r\n",init_rc);
    if (init_rc != 0) Error_Handler();

    /* Optional polling sanity — read 20 samples with 100 ms delay so you
     * can watch g_imu.getAccelX_mss() / getGyroX_dps() etc. in Live
     * Expressions BEFORE the DRDY interrupt starts corrupting subsequent
     * SPI bursts. */
    for (int i = 0; i < 20; i++) {
        HAL_Delay(100);
        g_imu.readSensor();
    }

    /* Gyro bias calibration — board must be stationary for ~0.25 s. */
    g_imu.estimateBias(800);

    /* Enable INT1 DRDY (active-HIGH pulse). From now on the EXTI callback
     * fires ~3200 times/sec and drives sensor reads. */
    if (!g_imu.enableDrdyInterrupt()) Error_Handler();
    printf("ICM DRDY INT1 enabled, 3200 Hz target\r\n");

    /* Main loop: sleep on __WFI, wake on any IRQ, process new sample. */
    uint32_t t_last_led   = HAL_GetTick();
    uint32_t t_last_rate  = HAL_GetTick();
    uint32_t c_last_drdy  = 0;
    uint32_t c_last_int2  = 0;

    for (;;) {
        if (g_data_ready) {
            g_data_ready = 0;
            /* Application logic hook: attitude estimation, control loop,
             * telemetry output. Fresh samples are in:
             *   g_imu.getAccel*_mss()  (m/s^2, body frame)
             *   g_imu.getGyro*_dps()   (dps,   body frame, bias-corrected)
             *   g_imu.getTemperature_C() */
        }

        uint32_t now = HAL_GetTick();

        if ((now - t_last_rate) >= 1000u) {
            uint32_t dt_ms = now - t_last_rate;
            g_drdy_rate_hz = (g_drdy_count - c_last_drdy) * 1000u / dt_ms;
            g_int2_rate_hz = (g_int2_count - c_last_int2) * 1000u / dt_ms;
            c_last_drdy = g_drdy_count;
            c_last_int2 = g_int2_count;
            t_last_rate = now;
            printf("[ICM] INT1=%lu Hz INT2=%lu Hz A_milli=%ld %ld %ld G_milli=%ld %ld %ld\r\n", (unsigned long)g_drdy_rate_hz,(unsigned long)g_int2_rate_hz, (long)(g_imu.getAccelX_mss()*1000.0f),(long)(g_imu.getAccelY_mss()*1000.0f),(long)(g_imu.getAccelZ_mss()*1000.0f),(long)(g_imu.getGyroX_dps()*1000.0f),(long)(g_imu.getGyroY_dps()*1000.0f),(long)(g_imu.getGyroZ_dps()*1000.0f));
        }

        if ((now - t_last_led) >= 1000u) {
            t_last_led = now;
            HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_2 | GPIO_PIN_10);
        }

        __WFI();
    }
}
