/**
 ******************************************************************************
 * @file    icm45686.cpp
 * @brief   Implementation of the STM32 HAL C++ wrapper for the TDK /
 *          InvenSense ICM-45686 six-axis IMU.
 *
 * @author  SaturnVex Firmware Team
 * @date    2026-08-01
 * @version 1.0.0
 *
 * @copyright
 * Copyright (c) 2026 Tuyen Nguyen (SaturnVex). All rights reserved.
 * Website: www.saturnvex.com  ·  Contact: support@saturnvex.com
 *
 * @license
 * SPDX-License-Identifier: MIT
 * See the root LICENSE file for the full license text. Third-party
 * components used by this file retain their own license terms; refer to
 * THIRD_PARTY_LICENSES.md.
 *
 * @details
 * ### SPI protocol summary
 *   - READ  : first TX byte = (reg | 0x80), then N dummy bytes.
 *             RX buffer[0] is the address-phase throwaway; payload starts
 *             at RX[1..N].
 *   - WRITE : first TX byte = (reg & 0x7F), then N data bytes.
 *             RX is discarded.
 *
 * ### Microsecond delay strategy
 * The TDK driver requires a `sleep_us` callback with sub-millisecond
 * precision. On this platform the callback uses the ARM DWT cycle
 * counter, which increments at CPU_CK (170 MHz on the STM32G474 — note this
 * is faster than SystemCoreClock, which main.c intentionally sets to
 * HCLK = 200 MHz for HAL_Delay). Sleeps ≥ 1 ms delegate to HAL_Delay to
 * save CPU cycles.
 *
 * ### Diagnostic logging
 * The macro `ICM_LOG(...)` is empty by default. Define `ICM_LOG_ENABLE=1`
 * project-wide and wire a `printf` redirect (SEGGER RTT, UART, SWO...)
 * to enable start-up diagnostics without recompiling the wrapper.
 ******************************************************************************
 */

/* ==== Includes ============================================================ */
#include "icm45686.h"

extern "C" {
#include "imu/inv_imu.h"        /* INV_IMU_WHOAMI, feature flags */
}

/* ==== Debug log macro ===================================================== */
/**
 * @def   ICM_LOG_ENABLE
 * @brief Compile-time switch for the internal diagnostic log macro.
 *        0 (default) → all ICM_LOG(...) calls compile away.
 *        1           → routed to stdio printf.
 */
#ifndef ICM_LOG_ENABLE
#define ICM_LOG_ENABLE 1
#endif

#if ICM_LOG_ENABLE
    #include <stdio.h>
    #define ICM_LOG(...)   printf(__VA_ARGS__)
#else
    #define ICM_LOG(...)   do { } while (0)
#endif

/* ==== Platform primitives ================================================= */

/**
 * @brief   True CPU clock frequency in Hz, used to convert microseconds
 *          into DWT cycle counts.
 *
 * The board clock tree is: PLL1 SYSCLK = 400 MHz, D1CPRE = /1, HPRE = /2.
 * DWT->CYCCNT increments at CPU_CK (400 MHz), not at HCLK. `SystemCoreClock`
 * is deliberately set to HCLK (200 MHz) in main.c so `HAL_Delay` uses the
 * SysTick clocked from HCLK — do not rely on it for DWT scaling.
 */
#define ICM_CPU_HZ           170000000UL

/** HAL SPI blocking transaction timeout, in milliseconds. */
#define ICM_SPI_TIMEOUT_MS   100u

/**
 * @brief  One-time enabler for the DWT cycle counter.
 * @note   Called at the start of Icm45686::begin(). Guarded by a local
 *         static so subsequent calls are no-ops.
 */
static void dwt_init(void)
{
    static bool done = false;
    if (done) return;
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT       = 0;
    DWT->CTRL        |= DWT_CTRL_CYCCNTENA_Msk;
    done = true;
}

/**
 * @brief  Chip-select-wrapped SPI burst.
 *
 * The CS line is driven low, `n` bytes are shifted out (and optionally in),
 * then CS is driven high again. The caller always packs the register
 * address into `tx[0]`; on reads, `rx[0]` is the address-phase throwaway
 * and the payload starts at `rx[1..n-1]`.
 *
 * @param  hspi    SPI peripheral handle (Master, Mode 0, 8-bit, MSB first).
 * @param  cs_port GPIO port of the chip-select pin.
 * @param  cs_pin  GPIO pin bitmask of the chip-select pin.
 * @param  tx      Transmit buffer of length @p n (never NULL).
 * @param  rx      Receive buffer of length @p n. Pass NULL for pure writes
 *                 (uses HAL_SPI_Transmit instead of TransmitReceive).
 * @param  n       Number of bytes to shift.
 */
static void spi_txn(SPI_HandleTypeDef *hspi, GPIO_TypeDef *cs_port, uint16_t cs_pin,
                    const uint8_t *tx, uint8_t *rx, uint32_t n)
{
    HAL_GPIO_WritePin(cs_port, cs_pin, GPIO_PIN_RESET);
    if (rx) {
        HAL_SPI_TransmitReceive(hspi, (uint8_t *)tx, rx, (uint16_t)n, ICM_SPI_TIMEOUT_MS);
    } else {
        HAL_SPI_Transmit(hspi, (uint8_t *)tx, (uint16_t)n, ICM_SPI_TIMEOUT_MS);
    }
    HAL_GPIO_WritePin(cs_port, cs_pin, GPIO_PIN_SET);
}

/* ==== Static class members ================================================ */

/*
 * Body-frame alignment matrices. Y and Z are flipped so a level board
 * reads accel = (0, 0, -g) — matches the FRD sign convention used
 * elsewhere in the SaturnVex flight stack.
 */
const int8_t Icm45686::tX[3] = { 1,  0,  0};
const int8_t Icm45686::tY[3] = { 0, -1,  0};
const int8_t Icm45686::tZ[3] = { 0,  0, -1};

/* ==== TDK C-driver transport callbacks ==================================== */
/*
 * The InvenSense driver takes C function pointers; these static methods
 * receive the object pointer through the void* `context` field the
 * constructor installed. They must not be called by application code.
 */

int Icm45686::spi_read_cb(void *ctx, uint8_t reg, uint8_t *buf, uint32_t len)
{
    Icm45686 *self = (Icm45686 *)ctx;
    uint8_t tx[64];
    uint8_t rx[64];
    if (len + 1 > sizeof(tx)) return -1;

    tx[0] = reg | 0x80;                                /* READ bit */
    for (uint32_t i = 0; i < len; i++) tx[i + 1] = 0;  /* dummy TX for RX */

    spi_txn(self->hspi_, self->cs_port_, self->cs_pin_, tx, rx, len + 1);

    /* rx[0] is dummy (address phase), payload starts at rx[1]. */
    for (uint32_t i = 0; i < len; i++) buf[i] = rx[i + 1];
    return 0;
}

int Icm45686::spi_write_cb(void *ctx, uint8_t reg, const uint8_t *buf, uint32_t len)
{
    Icm45686 *self = (Icm45686 *)ctx;
    uint8_t tx[64];
    if (len + 1 > sizeof(tx)) return -1;

    tx[0] = (uint8_t)(reg & 0x7F);                     /* WRITE bit */
    for (uint32_t i = 0; i < len; i++) tx[i + 1] = buf[i];

    spi_txn(self->hspi_, self->cs_port_, self->cs_pin_, tx, nullptr, len + 1);
    return 0;
}

void Icm45686::sleep_us_cb(uint32_t us)
{
    /* Sleeps of ≥ 1 ms delegate to HAL_Delay so the CPU can service other
     * interrupts. The residual sub-millisecond portion is busy-waited on
     * the DWT cycle counter for sub-microsecond precision.              */
    if (us >= 1000u) {
        HAL_Delay(us / 1000u);
        us %= 1000u;
        if (us == 0u) return;
    }
    const uint32_t cycles = us * (ICM_CPU_HZ / 1000000UL);
    const uint32_t start  = DWT->CYCCNT;
    while ((DWT->CYCCNT - start) < cycles) { /* spin */ }
}

/* ==== Construction ======================================================== */

Icm45686::Icm45686(SPI_HandleTypeDef *hspi, GPIO_TypeDef *cs_port, uint16_t cs_pin)
: hspi_(hspi), cs_port_(cs_port), cs_pin_(cs_pin),
  gyro_range_dps_(2000.0f),
  accel_range_g_(16.0f),
  temp_c(0.0f)
{
    for (int i = 0; i < 3; i++) {
        gyro_dps[i]        = 0.0f;
        accel_mss[i]       = 0.0f;
        bias_gyro_dps[i]   = 0.0f;
        bias_accel_mss[i]  = 0.0f;
    }

    memset(&drv_, 0, sizeof(drv_));
    drv_.transport.read_reg   = spi_read_cb;
    drv_.transport.write_reg  = spi_write_cb;
    drv_.transport.sleep_us   = sleep_us_cb;
    drv_.transport.context    = (void *)this;
    drv_.transport.serif_type = UI_SPI4;
}

/* ==== Interrupt configuration ============================================= */

/**
 * @brief  Configure INT1 for UI Data-Ready — push-pull, active-HIGH,
 *         PULSE mode. Called from the public enableDrdyInterrupt().
 */
bool Icm45686::enableDrdyInt1()
{
    inv_imu_int_pin_config_t pin_cfg;
    pin_cfg.int_polarity = INTX_CONFIG2_INTX_POLARITY_HIGH;
    pin_cfg.int_mode     = INTX_CONFIG2_INTX_MODE_PULSE;
    pin_cfg.int_drive    = INTX_CONFIG2_INTX_DRIVE_PP;

    if (inv_imu_set_pin_config_int(&drv_, INV_IMU_INT1, &pin_cfg) != 0) return false;

    inv_imu_int_state_t int_cfg;
    memset(&int_cfg, INV_IMU_DISABLE, sizeof(int_cfg));
    int_cfg.INV_UI_DRDY = INV_IMU_ENABLE;

    if (inv_imu_set_config_int(&drv_, INV_IMU_INT1, &int_cfg) != 0) return false;

    ICM_LOG("[ICM] UI_DRDY enabled on INT1 (ODR = %u Hz)\r\n",
            (unsigned)GYRO_ODR_HZ);
    return true;
}

bool Icm45686::enableFifoInterrupt(uint16_t watermark)
{
    (void)inv_imu_flush_fifo(&drv_);

    inv_imu_fifo_config_t fifo_cfg;
    fifo_cfg.gyro_en    = 1;
    fifo_cfg.accel_en   = 1;
    fifo_cfg.hires_en   = 0;   /* keep 16-bit resolution — 16-byte frames */
    fifo_cfg.fifo_wm_th = watermark;
    fifo_cfg.fifo_mode  = FIFO_CONFIG0_FIFO_MODE_STREAM;
    fifo_cfg.fifo_depth = FIFO_CONFIG0_FIFO_DEPTH_MAX;

    if (inv_imu_set_fifo_config(&drv_, &fifo_cfg) != 0) return false;

    inv_imu_int_pin_config_t pin_cfg;
    pin_cfg.int_polarity = INTX_CONFIG2_INTX_POLARITY_HIGH;
    pin_cfg.int_mode     = INTX_CONFIG2_INTX_MODE_PULSE;
    pin_cfg.int_drive    = INTX_CONFIG2_INTX_DRIVE_PP;

    if (inv_imu_set_pin_config_int(&drv_, INV_IMU_INT1, &pin_cfg) != 0) return false;

    inv_imu_int_state_t int_cfg;
    memset(&int_cfg, INV_IMU_DISABLE, sizeof(int_cfg));
    int_cfg.INV_FIFO_THS = INV_IMU_ENABLE;

    if (inv_imu_set_config_int(&drv_, INV_IMU_INT1, &int_cfg) != 0) return false;

    ICM_LOG("[ICM] FIFO+FIFO_THS enabled on INT1 (wm=%u)\r\n", (unsigned)watermark);
    return true;
}

/* ==== FIFO read =========================================================== */

bool Icm45686::readFromFifo()
{
    /* Errata AN-000364 requires reading the frame-count register twice;
     * inv_imu_get_frame_count() already handles that internally.        */
    uint16_t frame_count = 0;
    if (inv_imu_get_frame_count(&drv_, &frame_count) != 0) return false;
    if (frame_count == 0) return false;

    inv_imu_fifo_data_t frame;
    if (inv_imu_get_fifo_frame(&drv_, &frame) != 0) return false;

    /* A valid data frame carries BOTH accel_bit and gyro_bit; anything
     * else is a config/status packet and is silently skipped.           */
    if (frame.header.bits.accel_bit == 0 || frame.header.bits.gyro_bit == 0)
        return false;

    const float gscale = gyro_range_dps_        / 32768.0f;
    const float ascale = accel_range_g_ * 9.80665f / 32768.0f;

    const int16_t ar[3] = { frame.byte_16.accel_data[0],
                            frame.byte_16.accel_data[1],
                            frame.byte_16.accel_data[2] };
    const int16_t gr[3] = { frame.byte_16.gyro_data[0],
                            frame.byte_16.gyro_data[1],
                            frame.byte_16.gyro_data[2] };

    accel_mss[0] = ((float)(ar[0]*tX[0] + ar[1]*tX[1] + ar[2]*tX[2])) * ascale - bias_accel_mss[0];
    accel_mss[1] = ((float)(ar[0]*tY[0] + ar[1]*tY[1] + ar[2]*tY[2])) * ascale - bias_accel_mss[1];
    accel_mss[2] = ((float)(ar[0]*tZ[0] + ar[1]*tZ[1] + ar[2]*tZ[2])) * ascale - bias_accel_mss[2];

    gyro_dps[0]  = ((float)(gr[0]*tX[0] + gr[1]*tX[1] + gr[2]*tX[2])) * gscale - bias_gyro_dps[0];
    gyro_dps[1]  = ((float)(gr[0]*tY[0] + gr[1]*tY[1] + gr[2]*tY[2])) * gscale - bias_gyro_dps[1];
    gyro_dps[2]  = ((float)(gr[0]*tZ[0] + gr[1]*tZ[1] + gr[2]*tZ[2])) * gscale - bias_gyro_dps[2];

    /* 16-byte FIFO frame uses INT8 temp encoding: T_C = 25 + raw / 2.  */
    temp_c = 25.0f + (float)frame.byte_16.temp_data / 2.0f;
    return true;
}

/* ==== Initialisation ====================================================== */

int Icm45686::begin()
{
    int rc;

    dwt_init();                       /* Cycle counter for sleep_us_cb   */

    sleep_us_cb(20000);               /* POR settle: 20 ms                */

    /* Force soft reset via REG_MISC2 = 0x02 in case the chip is stuck
     * from a previous session (INT still asserted, FIFO misconfigured).
     * This is a write-only path and does not depend on WHO_AM_I.        */
    {
        uint8_t reset_val = 0x02;
        spi_write_cb((void *)this, 0x7F, &reset_val, 1);
        sleep_us_cb(5000);            /* 5 ms per driver comment          */
        ICM_LOG("[ICM] forced soft reset via REG_MISC2 = 0x02\r\n");
    }

    /* WHO_AM_I sanity: expect 0xE9 on ICM-45686. Retry a handful of
     * times to survive slow POR or a delayed CS ramp.                  */
    uint8_t whoami_dbg = 0;
    int probe_ok = 0;
    for (int attempt = 0; attempt < 5; attempt++) {
        spi_read_cb((void *)this, 0x72, &whoami_dbg, 1);
        ICM_LOG("[ICM] WHO_AM_I probe #%d = 0x%02X (expect 0xE9)\r\n",
                attempt, (unsigned)whoami_dbg);
        if (whoami_dbg == 0xE9) { probe_ok = 1; break; }
        sleep_us_cb(10000);
    }
    if (!probe_ok) {
        ICM_LOG("[ICM] WHO_AM_I never returned 0xE9 -- check SPI wiring + power.\r\n");
        return -1;
    }

    /* Driver-level init (WHO_AM_I check, transport bring-up). */
    rc = inv_imu_adv_init(&drv_);
    if (rc != 0) {
        ICM_LOG("[ICM] inv_imu_adv_init failed rc=%d\r\n", rc);
        return rc;
    }

    /* Accelerometer: ±16 g FSR, 3200 Hz ODR, Low-Noise mode. */
    rc  = inv_imu_set_accel_fsr      (&drv_, ACCEL_CONFIG0_ACCEL_UI_FS_SEL_16_G);
    rc |= inv_imu_set_accel_frequency(&drv_, ACCEL_CONFIG0_ACCEL_ODR_3200_HZ);
    rc |= inv_imu_set_accel_mode     (&drv_, PWR_MGMT0_ACCEL_MODE_LN);

    /* Gyroscope: ±2000 dps FSR, 3200 Hz ODR, Low-Noise mode. */
    rc |= inv_imu_set_gyro_fsr       (&drv_, GYRO_CONFIG0_GYRO_UI_FS_SEL_2000_DPS);
    rc |= inv_imu_set_gyro_frequency (&drv_, GYRO_CONFIG0_GYRO_ODR_3200_HZ);
    rc |= inv_imu_set_gyro_mode      (&drv_, PWR_MGMT0_GYRO_MODE_LN);
    if (rc != 0) {
        ICM_LOG("[ICM] start accel/gyro failed rc=%d\r\n", rc);
        return rc;
    }

    /* Let the sensor stabilise before the first sample. */
    sleep_us_cb(100000);              /* 100 ms                           */

    ICM_LOG("[ICM] init OK -- INT1 not enabled yet; call enableDrdyInterrupt() after polling test.\r\n");
    return 0;
}

/* ==== Sample acquisition ================================================== */

void Icm45686::readSensor()
{
    inv_imu_sensor_data_t d;
    if (inv_imu_get_register_data(&drv_, &d) != 0) return;

    const float gscale = gyro_range_dps_        / 32768.0f;    /* dps / LSB   */
    const float ascale = accel_range_g_ * 9.80665f / 32768.0f;  /* m·s⁻² / LSB */

    const int16_t gr[3] = { d.gyro_data[0],  d.gyro_data[1],  d.gyro_data[2]  };
    const int16_t ar[3] = { d.accel_data[0], d.accel_data[1], d.accel_data[2] };

    gyro_dps[0] = ((float)(gr[0]*tX[0] + gr[1]*tX[1] + gr[2]*tX[2])) * gscale - bias_gyro_dps[0];
    gyro_dps[1] = ((float)(gr[0]*tY[0] + gr[1]*tY[1] + gr[2]*tY[2])) * gscale - bias_gyro_dps[1];
    gyro_dps[2] = ((float)(gr[0]*tZ[0] + gr[1]*tZ[1] + gr[2]*tZ[2])) * gscale - bias_gyro_dps[2];

    accel_mss[0] = ((float)(ar[0]*tX[0] + ar[1]*tX[1] + ar[2]*tX[2])) * ascale - bias_accel_mss[0];
    accel_mss[1] = ((float)(ar[0]*tY[0] + ar[1]*tY[1] + ar[2]*tY[2])) * ascale - bias_accel_mss[1];
    accel_mss[2] = ((float)(ar[0]*tZ[0] + ar[1]*tZ[1] + ar[2]*tZ[2])) * ascale - bias_accel_mss[2];

    /* Register-path temperature encoding: T_C = 25 + raw / 128.        */
    temp_c = 25.0f + (float)d.temp_data / 128.0f;
}

/* ==== Bias helpers ======================================================== */

void Icm45686::setBias(float bx, float by, float bz)
{
    bias_gyro_dps[0] = bx;
    bias_gyro_dps[1] = by;
    bias_gyro_dps[2] = bz;
}

void Icm45686::setAccelBias(float bx, float by, float bz)
{
    bias_accel_mss[0] = bx;
    bias_accel_mss[1] = by;
    bias_accel_mss[2] = bz;
}

void Icm45686::estimateBias(unsigned n_samples)
{
    bias_gyro_dps[0] = bias_gyro_dps[1] = bias_gyro_dps[2] = 0.0f;

    float sum[3] = { 0.0f, 0.0f, 0.0f };
    for (unsigned i = 0; i < n_samples; i++) {
        readSensor();
        sum[0] += gyro_dps[0];
        sum[1] += gyro_dps[1];
        sum[2] += gyro_dps[2];
        sleep_us_cb(1000000u / GYRO_ODR_HZ);   /* one sample period at ODR */
    }
    bias_gyro_dps[0] = sum[0] / (float)n_samples;
    bias_gyro_dps[1] = sum[1] / (float)n_samples;
    bias_gyro_dps[2] = sum[2] / (float)n_samples;
}
