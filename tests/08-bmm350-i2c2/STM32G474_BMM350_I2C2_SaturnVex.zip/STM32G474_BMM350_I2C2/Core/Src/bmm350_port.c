/*
 * bmm350_port.c — Bridge Bosch BMM350 driver ↔ STM32 HAL I2C
 * Xem bmm350_port.h.
 */

#include "bmm350_port.h"
#include <string.h>

#define BMM350_PORT_I2C_TIMEOUT_MS   100u

/* Bosch BMM350 transmits two REAL dummy bytes on I2C read.
 * bmm350GetRegs() requests payload_len + 2 and removes the first two bytes.
 * Read all requested bytes from the device, including its dummy bytes.
 * See Bosch BST-BMM350-DS001-27 section 9.2.3. */
static int8_t bmm350_i2c_read(uint8_t reg_addr, uint8_t *reg_data,
                              uint32_t len, void *intf_ptr)
{
    bmm350_port_t *m = (bmm350_port_t *)intf_ptr;
    if (m == NULL || reg_data == NULL || len == 0u || len > UINT16_MAX)
        return BMM350_E_COM_FAIL;
    HAL_StatusTypeDef st = HAL_I2C_Mem_Read(m->hi2c,
                                            (uint16_t)(m->addr7 << 1),
                                            reg_addr,
                                            I2C_MEMADD_SIZE_8BIT,
                                            reg_data,
                                            (uint16_t)len,
                                            BMM350_PORT_I2C_TIMEOUT_MS);
    return (st == HAL_OK) ? BMM350_OK : BMM350_E_COM_FAIL;
}

static int8_t bmm350_i2c_write(uint8_t reg_addr, const uint8_t *reg_data,
                               uint32_t len, void *intf_ptr)
{
    bmm350_port_t *m = (bmm350_port_t *)intf_ptr;
    HAL_StatusTypeDef st = HAL_I2C_Mem_Write(m->hi2c,
                                             (uint16_t)(m->addr7 << 1),
                                             reg_addr,
                                             I2C_MEMADD_SIZE_8BIT,
                                             (uint8_t *)reg_data,
                                             (uint16_t)len,
                                             BMM350_PORT_I2C_TIMEOUT_MS);
    return (st == HAL_OK) ? BMM350_OK : BMM350_E_COM_FAIL;
}

/* HAL_Delay resolution is 1 ms; use a NOP busy-loop for the microsecond part.
 * On Cortex-M4 @ 170 MHz use a conservative NOP wait; overshoot is acceptable. Bosch specifies delays as
 * "at least N µs", so slight overshoot is acceptable. */
static void bmm350_delay_us(uint32_t period_us, void *intf_ptr)
{
    (void)intf_ptr;
    if (period_us >= 1000u) {
        HAL_Delay(period_us / 1000u);
        period_us %= 1000u;
    }
    volatile uint32_t n = period_us * 170u;
    while (n--) { __NOP(); }
}

/* --------------------------------------------------------------------------
 * Public API
 * -------------------------------------------------------------------------- */
int8_t bmm350_port_begin(bmm350_port_t *m, I2C_HandleTypeDef *hi2c, uint8_t addr7)
{
    memset(m, 0, sizeof(*m));
    m->hi2c  = hi2c;
    m->addr7 = addr7;

    m->dev.intfPtr = m;                    /* Callbacks receive bmm350_port_t*. */
    m->dev.read    = &bmm350_i2c_read;
    m->dev.write   = &bmm350_i2c_write;
    m->dev.delayUs = &bmm350_delay_us;

    int8_t rslt = bmm350Init(&m->dev);
    if (rslt != BMM350_OK) return rslt;

    /* HIGHACCURACY averaging (AVG=8) @ 25 Hz. */
    rslt = bmm350SetOdrPerformance(BMM350_DATA_RATE_25HZ,
                                   BMM350_AVERAGING_8, &m->dev);
    if (rslt != BMM350_OK) return rslt;

    rslt = bmm350_enable_axes(BMM350_X_EN, BMM350_Y_EN, BMM350_Z_EN, &m->dev);
    if (rslt != BMM350_OK) return rslt;

    rslt = bmm350SetPowerMode(eBmm350NormalMode, &m->dev);
    return rslt;
}

int8_t bmm350_port_read(bmm350_port_t *m)
{
    struct sBmm350MagTempData_t d;
    memset(&d, 0, sizeof(d));
    int8_t rslt = bmm350GetCompensatedMagXYZTempData(&d, &m->dev);
    if (rslt != BMM350_OK) return rslt;

    /* No axis remap — raw BMM350 frame. Add a remap here if fusing with an
     * IMU that uses a different body frame. */
    m->mag_ut[0] = d.x - m->bias_ut[0];
    m->mag_ut[1] = d.y - m->bias_ut[1];
    m->mag_ut[2] = d.z - m->bias_ut[2];
    m->temp_c    = d.temperature;
    return BMM350_OK;
}

bool bmm350_port_data_ready(bmm350_port_t *m)
{
    uint8_t status = 0;
    if (bmm350GetInterruptStatus(&status, &m->dev) != BMM350_OK) return false;
    return (status & 0x01u) != 0;
}

void bmm350_port_set_bias(bmm350_port_t *m, float bx, float by, float bz)
{
    m->bias_ut[0] = bx;
    m->bias_ut[1] = by;
    m->bias_ut[2] = bz;
}
