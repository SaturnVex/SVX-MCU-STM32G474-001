/*
 * bmm350_port.h — STM32 HAL wrapper for the Bosch BMM350 platform-independent
 * driver. Provides the three I2C callbacks required by Bosch (read, write,
 * delayUs) and exposes a small C API to the application.
 *
 * Wiring on IMU_BMI088Board (STM32H753):
 *   I2C1: PB6 = SCL, PB7 = SDA (external 2.2–4.7 kΩ pull-ups on board).
 *   Address 7-bit = 0x14 (ADSEL floating or GND) or 0x15 (ADSEL tied HIGH).
 */

#ifndef INC_BMM350_PORT_H_
#define INC_BMM350_PORT_H_

#include "stm32g4xx_hal.h"
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* HAL and bmm350_defs both define UNUSED with the same semantics but gcc
 * warns "macro redefined". Undefine the HAL one before including Bosch. */
#undef UNUSED
#include "bmm350_defs.h"
#include "bmm350.h"

typedef struct {
    I2C_HandleTypeDef *hi2c;
    uint8_t            addr7;         /* 7-bit I2C address */
    struct bmm350_dev  dev;           /* Bosch context */
    float              mag_ut[3];     /* compensated + bias-subtracted, µT   */
    float              temp_c;
    float              bias_ut[3];    /* software hard-iron correction, µT */
} bmm350_port_t;

/* Init: verify chip ID = 0x33, load OTP, soft reset, configure HIGHACCURACY
 * averaging @ 25 Hz, enable X/Y/Z axes, enter NORMAL mode.
 * Returns BMM350_OK (0) on success, negative Bosch error code on failure. */
int8_t bmm350_port_begin(bmm350_port_t *m, I2C_HandleTypeDef *hi2c, uint8_t addr7);

/* Read one compensated sample. Values available via bmm350_port_get_*(). */
int8_t bmm350_port_read(bmm350_port_t *m);

/* Poll DRDY bit (unused when the caller drives a fixed sampling period). */
bool   bmm350_port_data_ready(bmm350_port_t *m);

/* Software hard-iron bias — subtracted inside bmm350_port_read(). */
void   bmm350_port_set_bias(bmm350_port_t *m, float bx_ut, float by_ut, float bz_ut);

static inline float bmm350_port_get_x_ut(const bmm350_port_t *m){ return m->mag_ut[0]; }
static inline float bmm350_port_get_y_ut(const bmm350_port_t *m){ return m->mag_ut[1]; }
static inline float bmm350_port_get_z_ut(const bmm350_port_t *m){ return m->mag_ut[2]; }
static inline float bmm350_port_get_temp_c(const bmm350_port_t *m){ return m->temp_c; }

#ifdef __cplusplus
}
#endif

#endif /* INC_BMM350_PORT_H_ */
