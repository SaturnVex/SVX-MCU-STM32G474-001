STM32G474 PWM6 TEST / STM32CubeIDE

Based on original CubeMX STM32G474RBT6 project and the proven UART clock diagnostic.

PWM pins: TIM1_CH3 PA10, TIM1_CH4 PC3; TIM8_CH1 PC6, CH2 PC7, CH3 PC8, CH4 PC9.
APB2 timer clock 170 MHz; PSC=169; ARR=4999; PWM mode 1 active HIGH, 200 Hz (5 ms).
Every 1000 ms, CCR values go 1000,1100,...,2000 then wrap to 1000 (us).
USART2 PB3 TX (115200 baud) via VCP wiring; PB4 RX. LED1 PB2 and LED2 PB10 alternate every second.
Option Bytes previously configured on hardware: nSWBOOT0=0 nBOOT0=1; firmware cannot replace this setup.
Important: TIM1 and TIM8 start sequentially; channels within each timer are synchronized but two timers are not phase-locked.
Only debug UART, GPIO and the two TIM modules initialized; other peripherals excluded from runtime init.

CUBEMX NOTE: The included .ioc is from the original project and contains original timer defaults.
If regenerating code from CubeMX, first configure TIM1 and TIM8: PSC 169, ARR 4999, PWM mode 1, initial Pulse 1000, ARPE enabled. Otherwise regeneration may revert timer parameters.

This firmware has not been compiled with STM32CubeIDE nor tested on real hardware in this environment.
