/*
 * bmi088.c — Clean-room BMI088 accelerometer + gyroscope driver.
 *
 * Copyright (c) 2026 Tuyen Nguyen (SaturnVex). All rights reserved.
 * SPDX-License-Identifier: MIT
 *
 * Implementation is based solely on the public Bosch BMI088 datasheet:
 *   Document number BST-BMI088-DS001 (or later revision).
 * Register addresses, bit fields, initialization sequences, and data
 * encoding are technical facts published by Bosch; no third-party driver
 * source has been referenced or copied.
 *
 * SPI protocol summary (from datasheet §5.3):
 *   - Address byte: bit 7 = 1 for read, 0 for write; bits 6:0 = register.
 *   - Accel reads insert one dummy byte between address and payload.
 *   - Gyro reads have no dummy byte.
 *   - Multi-byte reads auto-increment the address.
 */

#include "bmi088.h"
#include <string.h>
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

/* Bosch BMI088 register addresses (public datasheet). */
#define BMI088_ACC_CHIP_ID        0x00u
#define BMI088_ACC_DATA_START     0x12u  /* X_LSB..Z_MSB (6 bytes) */
#define BMI088_ACC_TEMP_MSB       0x22u  /* MSB first, LSB at 0x23 */
#define BMI088_ACC_CONF           0x40u
#define BMI088_ACC_RANGE          0x41u
#define BMI088_ACC_INT1_IO_CTRL   0x53u
#define BMI088_ACC_INT_MAP_DATA   0x58u
#define BMI088_ACC_PWR_CONF       0x7Cu
#define BMI088_ACC_PWR_CTRL       0x7Du
#define BMI088_ACC_SOFT_RESET     0x7Eu

#define BMI088_GYR_CHIP_ID        0x00u
#define BMI088_GYR_DATA_START     0x02u  /* X_LSB..Z_MSB (6 bytes) */
#define BMI088_GYR_RANGE_REG      0x0Fu
#define BMI088_GYR_BANDWIDTH      0x10u
#define BMI088_GYR_SOFT_RESET     0x14u
#define BMI088_GYR_INT_CTRL       0x15u
#define BMI088_GYR_INT_IO_CONF    0x16u
#define BMI088_GYR_INT_IO_MAP     0x18u

#define BMI088_ACC_CHIP_ID_VAL    0x1Eu
#define BMI088_GYR_CHIP_ID_VAL    0x0Fu
#define BMI088_SOFT_RESET_CMD     0xB6u
#define BMI088_ACC_PWR_ON         0x04u
#define BMI088_ACC_MODE_ACTIVE    0x00u
#define BMI088_READ_BIT           0x80u

#define G_STANDARD                9.80665f
#define DEG2RAD                   (M_PI / 180.0f)

/* -------------------------------------------------------------------------
 * Low-level SPI helpers.
 * ------------------------------------------------------------------------- */

static int8_t spi_xfer(SPI_HandleTypeDef *hspi,
                       GPIO_TypeDef *cs_port, uint16_t cs_pin,
                       const uint8_t *tx, uint8_t *rx, uint16_t len)
{
    HAL_GPIO_WritePin(cs_port, cs_pin, GPIO_PIN_RESET);
    HAL_StatusTypeDef st = HAL_SPI_TransmitReceive(hspi, (uint8_t *)tx, rx,
                                                   len, HAL_MAX_DELAY);
    HAL_GPIO_WritePin(cs_port, cs_pin, GPIO_PIN_SET);
    return (st == HAL_OK) ? BMI088_OK : BMI088_ERR_SPI;
}

/* Accel: reads insert a dummy byte between address and payload. */
static int8_t acc_read(bmi088_t *dev, uint8_t reg, uint8_t *dst, uint16_t n)
{
    uint8_t tx[16] = { (uint8_t)(reg | BMI088_READ_BIT) };  /* rest zeroed */
    uint8_t rx[16] = { 0 };
    if ((n + 2u) > sizeof(tx)) return BMI088_ERR_SPI;
    int8_t r = spi_xfer(dev->hspi, dev->cs_acc_port, dev->cs_acc_pin,
                        tx, rx, (uint16_t)(n + 2u));
    if (r == BMI088_OK) memcpy(dst, &rx[2], n);
    return r;
}

static int8_t acc_write(bmi088_t *dev, uint8_t reg, uint8_t val)
{
    uint8_t tx[2] = { (uint8_t)(reg & 0x7Fu), val };
    uint8_t rx[2];
    return spi_xfer(dev->hspi, dev->cs_acc_port, dev->cs_acc_pin, tx, rx, 2);
}

/* Gyro: reads have no dummy byte. */
static int8_t gyr_read(bmi088_t *dev, uint8_t reg, uint8_t *dst, uint16_t n)
{
    uint8_t tx[16] = { (uint8_t)(reg | BMI088_READ_BIT) };
    uint8_t rx[16] = { 0 };
    if ((n + 1u) > sizeof(tx)) return BMI088_ERR_SPI;
    int8_t r = spi_xfer(dev->hspi, dev->cs_gyr_port, dev->cs_gyr_pin,
                        tx, rx, (uint16_t)(n + 1u));
    if (r == BMI088_OK) memcpy(dst, &rx[1], n);
    return r;
}

static int8_t gyr_write(bmi088_t *dev, uint8_t reg, uint8_t val)
{
    uint8_t tx[2] = { (uint8_t)(reg & 0x7Fu), val };
    uint8_t rx[2];
    return spi_xfer(dev->hspi, dev->cs_gyr_port, dev->cs_gyr_pin, tx, rx, 2);
}

/* -------------------------------------------------------------------------
 * Scale factor derivation (from datasheet §5.5 sensitivity tables).
 * ------------------------------------------------------------------------- */

static float acc_range_to_fs_mss(bmi088_acc_range_t r)
{
    /* Full scale in g = 3 * 2^(r+1). Convert to m/s^2. */
    static const float fs_g[] = { 3.0f, 6.0f, 12.0f, 24.0f };
    return fs_g[(int)r] * G_STANDARD;
}

static float gyr_range_to_fs_rads(bmi088_gyr_range_t r)
{
    static const float fs_dps[] = { 2000.0f, 1000.0f, 500.0f, 250.0f, 125.0f };
    return fs_dps[(int)r] * DEG2RAD;
}

/* -------------------------------------------------------------------------
 * Public API.
 * ------------------------------------------------------------------------- */

void bmi088_wake_gyro_spi(bmi088_t *dev)
{
    /* Toggle CS gyro LOW->HIGH three times so the gyro die latches SPI mode
     * (Bosch DS §5.3.2: auto protocol select on first CSB2 falling edge). */
    for (int i = 0; i < 3; i++) {
        HAL_GPIO_WritePin(dev->cs_gyr_port, dev->cs_gyr_pin, GPIO_PIN_RESET);
        HAL_Delay(1);
        HAL_GPIO_WritePin(dev->cs_gyr_port, dev->cs_gyr_pin, GPIO_PIN_SET);
        HAL_Delay(1);
    }
    HAL_Delay(5);
}

int8_t bmi088_probe(bmi088_t *dev)
{
    uint8_t id = 0;

    /* BMI088 accel: first SPI access after power-on may only select SPI mode.
     * Discard it, then read ID on the next independent CS transaction. */
    uint8_t spi_wakeup_discard = 0;
    (void)acc_read(dev, BMI088_ACC_CHIP_ID, &spi_wakeup_discard, 1);
    HAL_Delay(2);
    if (acc_read(dev, BMI088_ACC_CHIP_ID, &id, 1) != BMI088_OK)
        return BMI088_ERR_SPI;
    if (id != BMI088_ACC_CHIP_ID_VAL)
        return BMI088_ERR_CHIP_ID_ACC;

    if (gyr_read(dev, BMI088_GYR_CHIP_ID, &id, 1) != BMI088_OK)
        return BMI088_ERR_SPI;
    if (id != BMI088_GYR_CHIP_ID_VAL)
        return BMI088_ERR_CHIP_ID_GYR;

    return BMI088_OK;
}

int8_t bmi088_init(bmi088_t *dev)
{
    int8_t r;

    /* Zero cached state. */
    memset(dev->acc_mss,   0, sizeof(dev->acc_mss));
    memset(dev->gyr_rads,  0, sizeof(dev->gyr_rads));
    memset(dev->gyr_bias,  0, sizeof(dev->gyr_bias));
    dev->temp_c = 0.0f;

    /* Gyro protocol select + probe both dies. */
    bmi088_wake_gyro_spi(dev);
    r = bmi088_probe(dev);
    if (r != BMI088_OK) return r;

    /* Soft reset both dies. */
    r = acc_write(dev, BMI088_ACC_SOFT_RESET, BMI088_SOFT_RESET_CMD);
    if (r != BMI088_OK) return r;
    HAL_Delay(50);

    r = gyr_write(dev, BMI088_GYR_SOFT_RESET, BMI088_SOFT_RESET_CMD);
    if (r != BMI088_OK) return r;
    HAL_Delay(50);

    /* Reset returns accel to I2C default; the dummy transaction below
     * re-arms SPI (Bosch DS §5.3.2 for the accel die). */
    uint8_t dummy = 0;
    (void)acc_read(dev, BMI088_ACC_CHIP_ID, &dummy, 1);
    HAL_Delay(2);

    /* Accel power-up sequence: enable, then leave suspend. */
    r = acc_write(dev, BMI088_ACC_PWR_CTRL, BMI088_ACC_PWR_ON);
    if (r != BMI088_OK) return r;
    HAL_Delay(5);
    r = acc_write(dev, BMI088_ACC_PWR_CONF, BMI088_ACC_MODE_ACTIVE);
    if (r != BMI088_OK) return r;
    HAL_Delay(50);

    /* Default configuration: max range, top ODR. Caller may override. */
    r = bmi088_set_acc_range(dev, BMI088_ACC_RANGE_24G);      if (r) return r;
    r = bmi088_set_acc_odr  (dev, BMI088_ACC_ODR_1600_BW280); if (r) return r;
    r = bmi088_set_gyr_range(dev, BMI088_GYR_RANGE_2000DPS);  if (r) return r;
    r = bmi088_set_gyr_odr  (dev, BMI088_GYR_ODR_2000_BW532); if (r) return r;

    return BMI088_OK;
}

int8_t bmi088_set_acc_range(bmi088_t *dev, bmi088_acc_range_t range)
{
    int8_t r = acc_write(dev, BMI088_ACC_RANGE, (uint8_t)range);
    if (r != BMI088_OK) return r;
    dev->acc_scale = acc_range_to_fs_mss(range) / 32768.0f;
    return BMI088_OK;
}

int8_t bmi088_set_acc_odr(bmi088_t *dev, bmi088_acc_odr_t odr)
{
    return acc_write(dev, BMI088_ACC_CONF, (uint8_t)odr);
}

int8_t bmi088_set_gyr_range(bmi088_t *dev, bmi088_gyr_range_t range)
{
    int8_t r = gyr_write(dev, BMI088_GYR_RANGE_REG, (uint8_t)range);
    if (r != BMI088_OK) return r;
    dev->gyr_scale = gyr_range_to_fs_rads(range) / 32768.0f;
    return BMI088_OK;
}

int8_t bmi088_set_gyr_odr(bmi088_t *dev, bmi088_gyr_odr_t odr)
{
    return gyr_write(dev, BMI088_GYR_BANDWIDTH, (uint8_t)odr);
}

int8_t bmi088_config_acc_int1(bmi088_t *dev, bool open_drain,
                              bool active_low, bool map_drdy)
{
    /* ACC_INT1_IO_CTRL (0x53) bit layout per datasheet:
     *   bit 1  = int1_lvl  (0=active-low, 1=active-high)
     *   bit 2  = int1_od   (0=push-pull, 1=open-drain)
     *   bit 3  = int1_io   (0=input, 1=output)
     */
    uint8_t io = (1u << 3)                              /* output enable  */
               | (open_drain ? (1u << 2) : 0u)
               | (active_low ? 0u : (1u << 1));
    int8_t r = acc_write(dev, BMI088_ACC_INT1_IO_CTRL, io);
    if (r != BMI088_OK) return r;

    /* ACC_INT_MAP_DATA (0x58) bit 2 = int1_drdy. */
    uint8_t mapv = map_drdy ? (1u << 2) : 0u;
    return acc_write(dev, BMI088_ACC_INT_MAP_DATA, mapv);
}

/* Enable gyroscope data-ready on INT3. Matches PB1 EXTI falling + pull-up.
 * INT3 = active-low open-drain; INT4 left at its documented reset state.
 */
int8_t bmi088_config_gyr_int3_drdy(bmi088_t *dev)
{
    int8_t r;
    /* Gyro INT3 bits 1:0: open-drain=1, active-low=0; INT4 unchanged. */
    uint8_t io_conf;
    r = gyr_read(dev, BMI088_GYR_INT_IO_CONF, &io_conf, 1);
    if (r != BMI088_OK) return r;
    io_conf = (uint8_t)((io_conf & (uint8_t)~0x03u) | 0x02u);
    r = gyr_write(dev, BMI088_GYR_INT_IO_CONF, io_conf);
    if (r != BMI088_OK) return r;
    /* Route DRDY to INT3, keep other mapping bits intact. */
    uint8_t io_map;
    r = gyr_read(dev, BMI088_GYR_INT_IO_MAP, &io_map, 1);
    if (r != BMI088_OK) return r;
    r = gyr_write(dev, BMI088_GYR_INT_IO_MAP, (uint8_t)(io_map | 0x01u));
    if (r != BMI088_OK) return r;
    /* Bit 7 enables gyro new-data interrupt. */
    uint8_t ctrl;
    r = gyr_read(dev, BMI088_GYR_INT_CTRL, &ctrl, 1);
    if (r != BMI088_OK) return r;
    return gyr_write(dev, BMI088_GYR_INT_CTRL, (uint8_t)(ctrl | 0x80u));
}

/* Assemble a signed 16-bit little-endian value from a byte pair. */
static inline int16_t le16(const uint8_t *b) {
    return (int16_t)((uint16_t)b[0] | ((uint16_t)b[1] << 8));
}

int8_t bmi088_read_acc(bmi088_t *dev)
{
    uint8_t buf[6];
    int8_t r = acc_read(dev, BMI088_ACC_DATA_START, buf, 6);
    if (r != BMI088_OK) return r;
    dev->acc_mss[0] = (float)le16(&buf[0]) * dev->acc_scale;
    dev->acc_mss[1] = (float)le16(&buf[2]) * dev->acc_scale;
    dev->acc_mss[2] = (float)le16(&buf[4]) * dev->acc_scale;
    return BMI088_OK;
}

int8_t bmi088_read_gyr(bmi088_t *dev)
{
    uint8_t buf[6];
    int8_t r = gyr_read(dev, BMI088_GYR_DATA_START, buf, 6);
    if (r != BMI088_OK) return r;
    dev->gyr_rads[0] = (float)le16(&buf[0]) * dev->gyr_scale - dev->gyr_bias[0];
    dev->gyr_rads[1] = (float)le16(&buf[2]) * dev->gyr_scale - dev->gyr_bias[1];
    dev->gyr_rads[2] = (float)le16(&buf[4]) * dev->gyr_scale - dev->gyr_bias[2];
    return BMI088_OK;
}

int8_t bmi088_read_temp(bmi088_t *dev)
{
    /* Datasheet §5.4.4: two bytes at 0x22..0x23; MSB has upper 8 bits,
     * LSB has the remaining 3 bits in [7:5]. 11-bit two's complement,
     * resolution 0.125 °C, offset 23 °C. */
    uint8_t b[2];
    int8_t r = acc_read(dev, BMI088_ACC_TEMP_MSB, b, 2);
    if (r != BMI088_OK) return r;
    uint16_t u11 = ((uint16_t)b[0] << 3) | ((uint16_t)b[1] >> 5);
    int16_t  s11 = (u11 > 1023) ? (int16_t)(u11 - 2048) : (int16_t)u11;
    dev->temp_c = (float)s11 * 0.125f + 23.0f;
    return BMI088_OK;
}

int8_t bmi088_read_all(bmi088_t *dev)
{
    int8_t r;
    r = bmi088_read_acc (dev); if (r != BMI088_OK) return r;
    r = bmi088_read_gyr (dev); if (r != BMI088_OK) return r;
    r = bmi088_read_temp(dev); if (r != BMI088_OK) return r;
    return BMI088_OK;
}

int8_t bmi088_calibrate_gyro(bmi088_t *dev, uint16_t n_samples)
{
    if (n_samples == 0) return BMI088_OK;

    /* Zero bias while measuring. */
    dev->gyr_bias[0] = dev->gyr_bias[1] = dev->gyr_bias[2] = 0.0f;

    float sum[3] = {0.0f, 0.0f, 0.0f};
    for (uint16_t i = 0; i < n_samples; i++) {
        int8_t r = bmi088_read_gyr(dev);
        if (r != BMI088_OK) return r;
        sum[0] += dev->gyr_rads[0];
        sum[1] += dev->gyr_rads[1];
        sum[2] += dev->gyr_rads[2];
        HAL_Delay(2);
    }
    dev->gyr_bias[0] = sum[0] / (float)n_samples;
    dev->gyr_bias[1] = sum[1] / (float)n_samples;
    dev->gyr_bias[2] = sum[2] / (float)n_samples;
    return BMI088_OK;
}

void bmi088_set_gyr_bias(bmi088_t *dev, float bx, float by, float bz)
{
    dev->gyr_bias[0] = bx;
    dev->gyr_bias[1] = by;
    dev->gyr_bias[2] = bz;
}
