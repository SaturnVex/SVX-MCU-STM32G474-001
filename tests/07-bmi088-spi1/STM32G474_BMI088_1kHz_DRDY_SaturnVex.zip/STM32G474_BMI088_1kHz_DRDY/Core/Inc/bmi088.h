/*
 * bmi088.h — Clean-room BMI088 accelerometer + gyroscope driver.
 *
 * Copyright (c) 2026 Tuyen Nguyen (SaturnVex). All rights reserved.
 * SPDX-License-Identifier: MIT
 *
 * Implementation is based solely on the public Bosch BMI088 datasheet
 * (register maps, initialization sequences, and data encoding are facts
 * disclosed by Bosch and are not subject to copyright). No third-party
 * driver source has been referenced.
 *
 * Transport: STM32 HAL SPI + software chip-select (NSS_SOFT).
 *
 * Body frame convention: sensor die axes are exposed 1:1. If a specific
 * body frame (FRD, NED, ENU) is required, apply the rotation matrix in
 * the caller.
 */

#ifndef INC_BMI088_H_
#define INC_BMI088_H_

#include "stm32g4xx_hal.h"
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* -------------------------------------------------------------------------
 * Configuration enumerations (values match the underlying register fields).
 * ------------------------------------------------------------------------- */

typedef enum {
    BMI088_ACC_RANGE_3G  = 0x00,
    BMI088_ACC_RANGE_6G  = 0x01,
    BMI088_ACC_RANGE_12G = 0x02,
    BMI088_ACC_RANGE_24G = 0x03,
} bmi088_acc_range_t;

typedef enum {
    BMI088_GYR_RANGE_2000DPS = 0x00,
    BMI088_GYR_RANGE_1000DPS = 0x01,
    BMI088_GYR_RANGE_500DPS  = 0x02,
    BMI088_GYR_RANGE_250DPS  = 0x03,
    BMI088_GYR_RANGE_125DPS  = 0x04,
} bmi088_gyr_range_t;

/* Accelerometer output data rate + bandwidth (register ACC_CONF, addr 0x40).
 * Encoding: (bwp << 4) | odr where bwp={OSR4=0x0A, OSR2=0x09, Normal=0x08}
 * and odr={5..12 = 12.5, 25, 50, 100, 200, 400, 800, 1600 Hz}. */
typedef enum {
    BMI088_ACC_ODR_1600_BW280 = 0xAC,
    BMI088_ACC_ODR_800_BW230  = 0xAB,
    BMI088_ACC_ODR_400_BW145  = 0xAA,
    BMI088_ACC_ODR_200_BW80   = 0xA9,
    BMI088_ACC_ODR_100_BW40   = 0xA8,
} bmi088_acc_odr_t;

/* Gyroscope bandwidth + ODR (register GYRO_BANDWIDTH, addr 0x10).
 * Bit 7 is fixed 1. Lower bits select the pair. */
typedef enum {
    BMI088_GYR_ODR_2000_BW532 = 0x80,
    BMI088_GYR_ODR_2000_BW230 = 0x81,
    BMI088_GYR_ODR_1000_BW116 = 0x82,
    BMI088_GYR_ODR_400_BW47   = 0x83,
    BMI088_GYR_ODR_200_BW23   = 0x84,
    BMI088_GYR_ODR_100_BW12   = 0x85,
    BMI088_GYR_ODR_200_BW64   = 0x86,
    BMI088_GYR_ODR_100_BW32   = 0x87,
} bmi088_gyr_odr_t;

/* Driver context. Fields marked (RW) are updated by the driver on every
 * successful read; caller may inspect them but should not overwrite. */
typedef struct {
    /* Wiring (fill in before calling bmi088_probe). */
    SPI_HandleTypeDef *hspi;
    GPIO_TypeDef      *cs_acc_port;
    uint16_t           cs_acc_pin;
    GPIO_TypeDef      *cs_gyr_port;
    uint16_t           cs_gyr_pin;

    /* Cached scale factors (populated during bmi088_set_*_range). */
    float acc_scale;      /* m/s^2 per raw count (RW) */
    float gyr_scale;      /* rad/s per raw count (RW) */

    /* Latest measurement. Refreshed by bmi088_read_all / bmi088_read_*. */
    float acc_mss[3];     /* X, Y, Z m/s^2  (RW) */
    float gyr_rads[3];    /* X, Y, Z rad/s  (RW) */
    float temp_c;         /* °C            (RW) */

    /* Subtracted from every subsequent sample. Set by bmi088_calibrate_gyro
     * or manually via bmi088_set_gyr_bias. */
    float gyr_bias[3];
} bmi088_t;

/* -------------------------------------------------------------------------
 * Return codes.
 * ------------------------------------------------------------------------- */
#define BMI088_OK               ( 0)
#define BMI088_ERR_CHIP_ID_ACC  (-1)
#define BMI088_ERR_CHIP_ID_GYR  (-2)
#define BMI088_ERR_SPI          (-3)
#define BMI088_ERR_VERIFY       (-4)

/* -------------------------------------------------------------------------
 * Public API.
 * ------------------------------------------------------------------------- */

/* Probe both dies. Returns BMI088_OK when accel_chip_id == 0x1E and
 * gyro_chip_id == 0x0F. Call after CS pins are HIGH and the gyro CS has
 * been pulsed once (or bmi088_wake_gyro_spi has been invoked). */
int8_t bmi088_probe(bmi088_t *dev);

/* GPIO-only CS pulse on the gyro line — needed after chip power-up because
 * the gyro die auto-detects protocol from the first CSB2 falling edge.
 * Emit before any SPI transaction targeted at the gyro. */
void bmi088_wake_gyro_spi(bmi088_t *dev);

/* Soft reset + power up both dies, leave them at driver default range/ODR
 * (accel 24 g / 1600 Hz, gyro 2000 dps / 2000 Hz). Returns BMI088_OK on
 * successful chip ID verification and register writes. */
int8_t bmi088_init(bmi088_t *dev);

/* Change accel range (updates acc_scale) and ODR/bandwidth. */
int8_t bmi088_set_acc_range(bmi088_t *dev, bmi088_acc_range_t range);
int8_t bmi088_set_acc_odr  (bmi088_t *dev, bmi088_acc_odr_t   odr);

/* Change gyro range (updates gyr_scale) and ODR/bandwidth. */
int8_t bmi088_set_gyr_range(bmi088_t *dev, bmi088_gyr_range_t range);
int8_t bmi088_set_gyr_odr  (bmi088_t *dev, bmi088_gyr_odr_t   odr);

/* Configure accel INT1 pin: output enable, drive mode, polarity. If
 * map_drdy=true the pin toggles at accel ODR; if false it remains idle. */
int8_t bmi088_config_acc_int1(bmi088_t *dev, bool open_drain,
                              bool active_low, bool map_drdy);

/* Route gyroscope Data Ready to INT3 (active-low, open-drain). */
int8_t bmi088_config_gyr_int3_drdy(bmi088_t *dev);

/* Read accel, gyro, and temperature in sequence. Populates acc_mss[],
 * gyr_rads[] (bias-corrected), and temp_c. */
int8_t bmi088_read_all(bmi088_t *dev);

/* Individual reads (all update the corresponding fields). */
int8_t bmi088_read_acc (bmi088_t *dev);
int8_t bmi088_read_gyr (bmi088_t *dev);
int8_t bmi088_read_temp(bmi088_t *dev);

/* Averages n_samples gyro readings and stores the mean as gyr_bias so that
 * bmi088_read_gyr subtracts it. Board must be stationary during the call.
 * ~n_samples * 2 ms real time (blocking). */
int8_t bmi088_calibrate_gyro(bmi088_t *dev, uint16_t n_samples);

/* Manual bias override (units: rad/s). */
void   bmi088_set_gyr_bias(bmi088_t *dev, float bx, float by, float bz);

#ifdef __cplusplus
}
#endif

#endif /* INC_BMI088_H_ */
