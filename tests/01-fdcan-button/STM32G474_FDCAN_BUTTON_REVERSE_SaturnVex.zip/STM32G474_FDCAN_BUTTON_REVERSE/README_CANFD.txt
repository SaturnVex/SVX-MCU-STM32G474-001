STM32G474 FDCAN1->FDCAN2 physical CAN FD bus test
FDCAN1 PB9 TX / PB8 RX, FDCAN2 PB13 TX / PB12 RX.
PB7 and PB11 are transceiver STBY active HIGH, held LOW.
Join CANH to CANH and CANL to CANL between the two transceivers, common GND, correct termination, power both.
BOOT0 option bytes nSWBOOT0=0,nBOOT0=1 for PB8 CAN1 RX; keep BOOT0 jumper open.
500 kbps nominal; 1 Mbps data; FD+BRS 16 bytes every second. UART2 115200 STLink VCP.
This is physical normal mode, NOT internal test loopback.
CubeMX IOC remains baseline-derived; do not regenerate code without syncing configuration.

Payload 16 bytes: byte[i] = (frame_sequence + i) & 0xFF, i=0..15. Prints TX DATA and RX DATA in hex, checks 16-byte exact match.
