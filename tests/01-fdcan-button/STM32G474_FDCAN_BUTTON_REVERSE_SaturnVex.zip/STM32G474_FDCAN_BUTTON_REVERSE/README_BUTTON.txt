BUTTON PC13 assumed active-low, internal pull-up; check schematic polarity.
Press and release: alternate CAN1 TX/CAN2 RX and CAN2 TX/CAN1 RX.
Each press resets all application counters and 16-byte ramp.
Physically connect CANH-CANH, CANL-CANL and GND. Both STBY low.
No internal loopback. No IMU/ADC/PWM initialized.
.io c metadata copied from earlier baseline: avoid Generate Code.
