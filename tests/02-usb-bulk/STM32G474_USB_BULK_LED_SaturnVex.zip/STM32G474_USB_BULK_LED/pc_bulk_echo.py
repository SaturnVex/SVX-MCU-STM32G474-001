#!/usr/bin/env python3
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
# SaturnVex USB Bulk host-side test application.
# www.saturnvex.com | support@saturnvex.com
"""STM32G474 vendor-specific USB Full-Speed Bulk echo test.

Install on Windows:
  python -m pip install --upgrade pyusb libusb-package
Use Zadig to bind WinUSB to USB VID_CAFE&PID_4001 (not the ST-LINK).
Run:
  python pc_bulk_echo.py --count 20
"""

import argparse
import sys
import time

import usb.core
import usb.util

VID = 0xCAFE
PID = 0x4001
EP_OUT = 0x01
EP_IN = 0x81
PACKET_SIZE = 16


def open_usb_device():
    try:
        import libusb_package
    except ImportError:
        raise RuntimeError(
            "Missing libusb-package. Run: python -m pip install --upgrade pyusb libusb-package"
        ) from None

    # libusb-package supplies its own libusb DLL/backend on Windows.
    device = libusb_package.find(idVendor=VID, idProduct=PID)
    if device is None:
        raise RuntimeError(
            "USB device CAFE:4001 not found. Check STM32 USB connector, "
            "enumeration in Device Manager, and WinUSB (via Zadig)."
        )
    return device


def main():
    parser = argparse.ArgumentParser(description="STM32G474 USB Bulk OUT/IN echo test (not CDC COM)")
    parser.add_argument("--count", type=int, default=20, help="Number of packets (default 20)")
    parser.add_argument("--length", type=int, default=PACKET_SIZE,
                        help="Bytes per packet, 1..64 (default 16)")
    parser.add_argument("--timeout", type=int, default=2000, help="USB timeout in ms")
    parser.add_argument("--interval", type=float, default=0.1,
                        help="Delay between packets in seconds")
    args = parser.parse_args()
    if args.count < 1 or not 1 <= args.length <= 64 or args.timeout < 1 or args.interval < 0:
        parser.error("Require --count >= 1, --length 1..64, --timeout >= 1, --interval >= 0")

    dev = None
    claimed = False
    try:
        dev = open_usb_device()
        # Firmware exposes a single vendor-specific interface (interface 0).
        dev.set_configuration()
        usb.util.claim_interface(dev, 0)
        claimed = True
        print(f"USB connected: VID={VID:04X}, PID={PID:04X}, Bulk OUT={EP_OUT:02X}, IN={EP_IN:02X}")

        passed = 0
        failed = 0
        for seq in range(args.count):
            payload = bytes(((seq + i) & 0xFF) for i in range(args.length))
            sent = dev.write(EP_OUT, payload, timeout=args.timeout)
            if sent != len(payload):
                raise RuntimeError(f"Short USB write: {sent}/{len(payload)} bytes")
            received = bytes(dev.read(EP_IN, 64, timeout=args.timeout))
            ok = received == payload
            passed += int(ok)
            failed += int(not ok)
            print(f"{seq + 1:03d} TX: {payload.hex(' ').upper()}")
            print(f"    RX: {received.hex(' ').upper()}  {'PASS' if ok else 'FAIL'}")
            if args.interval:
                time.sleep(args.interval)

        print(f"RESULT: PASS={passed}, FAIL={failed}, total={args.count}")
        return 0 if failed == 0 else 1
    except usb.core.USBError as exc:
        print(f"USB error: {exc}", file=sys.stderr)
        print("Check WinUSB driver, USB enumeration, cable, and STM32 firmware.", file=sys.stderr)
        return 2
    except (RuntimeError, usb.core.NoBackendError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    finally:
        if dev is not None:
            if claimed:
                try:
                    usb.util.release_interface(dev, 0)
                except usb.core.USBError:
                    pass
            usb.util.dispose_resources(dev)


if __name__ == "__main__":
    sys.exit(main())
