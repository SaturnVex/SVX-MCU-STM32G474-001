STM32G474 USB Vendor-Specific Bulk Echo
PA11 DM, PA12 DP, USB FS. Not CDC; no virtual COM port.
VID 0xCAFE PID 0x4001 are DEVELOPMENT/EXAMPLE identifiers only; replace with legitimately assigned IDs before distribution.
Endpoints: 0x01 OUT and 0x81 IN (64-byte max). A packet <=64 bytes is echoed.
Windows: install WinUSB only for device CAFE:4001 using Zadig; run pip install pyusb; python pc_bulk_echo.py --count 20.
Linux: pip install pyusb; make sure libusb and user permissions (udev) permit access.
Do NOT connect this port through STLINK virtual COM: use the G474 USB port.
NOTE: Firmware is source-reviewed but NOT built or tested on hardware.
IOC is retained from LED baseline; CubeMX Generate Code could overwrite manual USB class implementation.
