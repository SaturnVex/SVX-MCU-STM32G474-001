USB hardware bring-up patch (USB Vendor-Specific Bulk, NOT CDC)
STM32G474RB: PA11/PA12 AF10 USB; PWR CR2 USV; EP0 IN data status OUT.
Derived from STM32G474_USB_BULK_LED_IRQ_FIXED.
NOT hardware-verified or arm-none-eabi compiled.
