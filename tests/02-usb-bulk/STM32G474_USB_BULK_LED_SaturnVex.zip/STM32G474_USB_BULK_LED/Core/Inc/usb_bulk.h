#ifndef USB_BULK_H
#define USB_BULK_H
#include "main.h"
HAL_StatusTypeDef USB_Bulk_Start(PCD_HandleTypeDef *pcd);
void USB_Bulk_Task(void);
#endif
