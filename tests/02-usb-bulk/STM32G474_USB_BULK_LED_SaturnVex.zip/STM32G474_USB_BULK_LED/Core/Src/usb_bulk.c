/*
 * SaturnVex application notice
 * Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
 * www.saturnvex.com | support@saturnvex.com
 *
 * Vendor-specific USB Device enumeration and Bulk echo implementation.
 * STM32 HAL components retain their respective copyright and license terms.
 */
#include "usb_bulk.h"
#include <string.h>
/* USB vendor-specific interface: endpoint 0x01 OUT, endpoint 0x81 IN, 64 bytes. */
#define EP_OUT 0x01U
#define EP_IN 0x81U
#define EP0_MPS 64U
static PCD_HandleTypeDef *dev;
static volatile uint8_t configured, in_busy, rx_ready;
static volatile uint16_t rx_size;
static uint8_t rx_buf[64], tx_buf[64];
static uint8_t control_zlp[1];
static uint16_t pending_address;
static uint8_t set_addr_pending;
static const uint8_t dev_desc[18]={
  18,1,0x00,0x02,0x00,0x00,0x00,64,0xFE,0xCA,0x01,0x40,
  0x00,0x01,1,2,3,1
};
static const uint8_t cfg_desc[32]={
  9,2,32,0,1,1,0,0x80,50,
  9,4,0,0,2,0xFF,0x00,0x00,0,
  7,5,EP_OUT,2,64,0,0,
  7,5,EP_IN,2,64,0,0
};
static const uint8_t lang_desc[]={4,3,0x09,0x04};
static uint8_t str_desc[64];
static uint16_t mkstr(const char *txt){
  uint16_t i=0; while(txt[i] && i<31){str_desc[2+i*2]=(uint8_t)txt[i];str_desc[3+i*2]=0;i++;}
  str_desc[0]=(uint8_t)(2+2*i);str_desc[1]=3;return (uint16_t)(2+2*i);
}
static void control_in(uint8_t *buf,uint16_t count,uint16_t req){
  if(count>req) count=req;
  HAL_PCD_EP_Transmit(dev,0x80,buf,count);
}
static void control_ack(void){ HAL_PCD_EP_Transmit(dev,0x80,control_zlp,0); }
static void control_fail(void){ HAL_PCD_EP_SetStall(dev,0x80);HAL_PCD_EP_SetStall(dev,0); }
HAL_StatusTypeDef USB_Bulk_Start(PCD_HandleTypeDef *pcd){
  dev=pcd;
  HAL_PCDEx_PMAConfig(dev,0x00,PCD_SNG_BUF,0x40);
  HAL_PCDEx_PMAConfig(dev,0x80,PCD_SNG_BUF,0x80);
  HAL_PCDEx_PMAConfig(dev,EP_OUT,PCD_SNG_BUF,0xC0);
  HAL_PCDEx_PMAConfig(dev,EP_IN,PCD_SNG_BUF,0x100);
  HAL_NVIC_SetPriority(USB_LP_IRQn,5,0);
  HAL_NVIC_EnableIRQ(USB_LP_IRQn);
  return HAL_PCD_Start(dev);
}
/* Use the PCD handle passed in USB_Bulk_Start(), avoiding a hidden global dependency. */
void USB_LP_IRQHandler(void){ if (dev != NULL) HAL_PCD_IRQHandler(dev); }
void USB_HP_IRQHandler(void){ if (dev != NULL) HAL_PCD_IRQHandler(dev); }
void HAL_PCD_ResetCallback(PCD_HandleTypeDef *h){
  configured=0;rx_ready=0;in_busy=0;set_addr_pending=0;
  HAL_PCD_EP_Open(h,0,EP0_MPS,EP_TYPE_CTRL);
  HAL_PCD_EP_Open(h,0x80,EP0_MPS,EP_TYPE_CTRL);
  HAL_PCD_EP_Receive(h,0,control_zlp,0);
}
void HAL_PCD_SetupStageCallback(PCD_HandleTypeDef *h){
  uint8_t *s=(uint8_t*)h->Setup;
  uint8_t bm=s[0], request=s[1];
  uint16_t value=(uint16_t)s[2]|((uint16_t)s[3]<<8);
  uint16_t length=(uint16_t)s[6]|((uint16_t)s[7]<<8);
  if((bm&0x60U)!=0){ control_fail();return; }
  if(request==6 && (bm&0x80)){ /* GET_DESCRIPTOR */
    switch(value>>8){
      case 1:control_in((uint8_t*)dev_desc,sizeof(dev_desc),length);return;
      case 2:control_in((uint8_t*)cfg_desc,sizeof(cfg_desc),length);return;
      case 3:
        if((value&255)==0){control_in((uint8_t*)lang_desc,sizeof(lang_desc),length);return;}
        if((value&255)==1){control_in(str_desc,mkstr("SaturnVex"),length);return;}
        if((value&255)==2){control_in(str_desc,mkstr("G474 USB Bulk Test"),length);return;}
        if((value&255)==3){control_in(str_desc,mkstr("G474USB001"),length);return;}
        break;
    }
  }
  if(request==5 && bm==0){ /* SET_ADDRESS: HAL handles proper HW address transition. */
    pending_address=value & 0x7FU;
    set_addr_pending=1;
    control_ack();return;
  }
  if(request==9 && bm==0){ /* SET_CONFIGURATION */
    if(value==1){
      HAL_PCD_EP_Open(h,EP_OUT,64,EP_TYPE_BULK);
      HAL_PCD_EP_Open(h,EP_IN,64,EP_TYPE_BULK);
      configured=1;rx_ready=0;in_busy=0;
      HAL_PCD_EP_Receive(h,EP_OUT,rx_buf,sizeof(rx_buf));
      control_ack();return;
    }
    if(value==0){configured=0;HAL_PCD_EP_Close(h,EP_OUT);HAL_PCD_EP_Close(h,EP_IN);control_ack();return;}
  }
  if(request==8 && bm==0x80){ /* GET_CONFIGURATION */
    static uint8_t cfg;cfg=configured?1:0;control_in(&cfg,1,length);return;
  }
  if(request==0 && (bm&0x80)){ /* GET_STATUS */
    static uint8_t status[2]={0,0};control_in(status,2,length);return;
  }
  if(request==10 && bm==0x81){ /* GET_INTERFACE */
    static uint8_t alt=0;control_in(&alt,1,length);return;
  }
  if(request==11 && bm==0x01 && value==0){control_ack();return;}
  control_fail();
}
void HAL_PCD_DataInStageCallback(PCD_HandleTypeDef *h,uint8_t ep){
  if(ep==0){
    if(set_addr_pending){
      HAL_PCD_SetAddress(h,(uint8_t)pending_address);
      set_addr_pending=0;
    } else {
      /* Host STATUS OUT phase after device-to-host control data. */
      HAL_PCD_EP_Receive(h,0,control_zlp,0);
    }
  }
  if(ep==1){in_busy=0;if(configured)HAL_PCD_EP_Receive(h,EP_OUT,rx_buf,sizeof(rx_buf));}
}
void HAL_PCD_DataOutStageCallback(PCD_HandleTypeDef *h,uint8_t ep){
  if(ep==1 && configured){
    rx_size=(uint16_t)HAL_PCD_EP_GetRxCount(h,EP_OUT);
    if(rx_size>64)rx_size=64;
    rx_ready=1;
  }
}
void USB_Bulk_Task(void){
  if(!configured || !rx_ready || in_busy)return;
  __disable_irq();
  uint16_t n=rx_size;
  memcpy(tx_buf,rx_buf,n);
  rx_ready=0;
  in_busy=1;
  __enable_irq();
  if(HAL_PCD_EP_Transmit(dev,EP_IN,tx_buf,n)!=HAL_OK)in_busy=0;
}
