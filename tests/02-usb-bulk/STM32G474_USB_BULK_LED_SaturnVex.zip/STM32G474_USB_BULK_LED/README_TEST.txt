STM32G474 LED + IO TOGGLE TEST

Independent project from GPIO_LED_verified_GPIO_test baseline (no PWM).
Clock: internal HSI 16 MHz, SystemClock_Config is NOT called.
LED1 PB2 and LED2 PB10 alternate.
IO_1 PB15, IO_2 PA15, IO_3 PB5, IO_4 PB6 toggle together, in phase with LED1.
Uses same diagnostic_delay() as verified baseline, approximate period depending on optimization.
This test does not initialize UART or TIM1/TIM8 or the other peripherals.
Import via File > Import > Existing Projects into Workspace and build/flash new ELF.
Firmware replaces image on device, but project folders remain separate.
The retained .ioc is inherited from the original CubeMX project and does not represent this minimal GPIO-only runtime; generating code from CubeMX can overwrite the custom main.c.
