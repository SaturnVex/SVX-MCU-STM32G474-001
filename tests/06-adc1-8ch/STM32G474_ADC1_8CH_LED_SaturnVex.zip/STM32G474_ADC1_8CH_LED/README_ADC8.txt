STM32G474RBT6 ADC1 eight-channel polling demonstration based on original LED baseline.
ADC1 IN1 PA0, IN2 PA1, IN3 PA2, IN4 PA3, IN5 PB14, IN6 PC0, IN7 PC1, IN8 PC2.
IN5 is connected to VBUS voltage divider in PCB design (R15=R16=10.2k).
GPIO PB2 LED1 and PB10 LED2 alternate every 500ms. USART2 PB3 TX PB4 RX 115200baud.
12-bit regular scan ranks 1..8, single-ended calibrated, polling 8 conversions once per 500ms.
VREF nominal 3.3V: voltages printed are estimates and require measured VREF for accuracy.
Only ADC1, GPIO LEDs, UART2 and SYSCLK initialized. Other CubeMX generated peripheral functions are unused and not activated.
NOTE CubeMX regeneration will overwrite manual main() and must be reviewed.
